import fs from 'node:fs/promises';

import bodyParser from 'body-parser';
import express from 'express';

const app = express();

app.use(bodyParser.json());

// CORS

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*'); // allow all domains
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  next();
});

app.get('/tasks', async (req, res) => {
  console.log('Hit GET API');
  const fileContent = await fs.readFile('./data/tasks.json');

  const tasksData = JSON.parse(fileContent);

  res.status(200).json({ tasks: tasksData });
});

app.put('/tasks', async (req, res) => {
  console.log('Hit PUT API');
  const tasks = req.body.tasks;
  console.log(tasks);
  await fs.writeFile('./data/tasks.json', JSON.stringify(tasks));

  res.status(200).json({ message: 'Tasks updated!' });
});

// 404
app.use((req, res, next) => {
  if (req.method === 'OPTIONS') {
    return next();
  }
  res.status(404).json({ message: '404 - Not Found' });
});

app.listen(3001);












// ------------------
// const express = require('express')
// const app = express()
// const port = 3000

// app.get('/', (req, res) => {
//   res.send('Hello World!')
// })

// app.get('/tasks',(req,res)=> {
//     res.send('Getting')
// })

// app.post('/task',(req,res)=>{
    
// })

// app.listen(port, () => {
//   console.log(`Example app listening on port ${port}`)
// })