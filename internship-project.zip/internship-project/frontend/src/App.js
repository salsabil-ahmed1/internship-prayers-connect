import { useEffect, useState } from 'react';
import './App.css';
import Tab from './components/Tab'
import { TASK_STATUS_COMPLETED, TASK_STATUS_IN_PROGRESS, TASK_STATUS_TODO } from './data';
import { TaskContext } from './store/tasks-context';

function App() {
  const [tasks, setTasks] = useState([]);

  useEffect(()=> {
    getTasksFromBackend();
  }, []);

  function getTasksFromBackend() {
    fetch('http://localhost:3001/tasks')
    .then(response => response.json())
    .then(resData => setTasks(resData.tasks));
  }

  async function updateStatusInBackend(tasks) {
    const response = await fetch('http://localhost:3001/tasks', {
      method: 'PUT',
      body: JSON.stringify({tasks: tasks}),
      headers: {
        'Content-Type': 'application/json'
      }
    });
    const resData = (await response).json;
    
    if(!(await response).ok) {
      throw new Error('failed to update task status');
    }
    return resData.message;
  }

  async function handleStatusChange(id, newStatus) {
    const newTasks = tasks.map(task => {
      if (task.id === id) {
        task.status = newStatus;
        return task;
      } else {
        return task;
      }
    });
    setTasks(newTasks);

    await updateStatusInBackend(newTasks);
  }

  const contextValue = {
    tasks: tasks,
    changeTaskStatus: handleStatusChange
  };

  return (
    <TaskContext.Provider value={contextValue}>
      <Tab status={TASK_STATUS_TODO} />
      <Tab status={TASK_STATUS_IN_PROGRESS} />
      <Tab status={TASK_STATUS_COMPLETED} />
    </TaskContext.Provider>
  );
}

export default App;