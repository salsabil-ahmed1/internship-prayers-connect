import { useContext } from 'react';
import './Tab.css'
import Task from './Task';
import { TaskContext } from '../store/tasks-context';

export default function Tab({ status }) {
    const { tasks } = useContext(TaskContext);

    const items = tasks.filter(task => task.status === status).map(task => {
        // console.log(task);
        return <li key={task.id} style={{ 'list-style-type': 'none', margin: 0, padding: 0 }}><Task {...task} /></li>
    });

    return (
        <div id="tab">
            <h2>{status}</h2>
            <ul>{items}</ul>
        </div>
    );
}