import TaskButton from "./TaskButton";
import { TASK_STATUS_TODO, TASK_STATUS_IN_PROGRESS, TASK_STATUS_COMPLETED } from "../data";
import { useContext } from "react";
import { TaskContext } from "../store/tasks-context";

function Task({ id, title, description, status }) {

    const { changeTaskStatus } = useContext(TaskContext);

    function handleClick(moveToStatus) {
        changeTaskStatus(id, moveToStatus);
    }

    function renderButtons() {
        if (status === TASK_STATUS_TODO) {
            return <TaskButton onClick={() => handleClick(TASK_STATUS_IN_PROGRESS)}>Move to {TASK_STATUS_IN_PROGRESS}</TaskButton>;
        } else if (status === TASK_STATUS_IN_PROGRESS) {
            return <div>
                <TaskButton onClick={() => handleClick(TASK_STATUS_TODO)}>Move to {TASK_STATUS_TODO}</TaskButton>
                <TaskButton onClick={() => handleClick(TASK_STATUS_COMPLETED)}>Move to {TASK_STATUS_COMPLETED}</TaskButton>
            </div>;
        } else if (status === TASK_STATUS_COMPLETED) {
            return <TaskButton onClick={() => handleClick(TASK_STATUS_IN_PROGRESS)}>Move to {TASK_STATUS_IN_PROGRESS}</TaskButton>;
        }
    }

    return (
        <div>
            <h2>Title: {title}</h2>
            <p>Description: {description}</p>
            <p>Status: {status}</p>
            {renderButtons()}
        </div>
    );
}

export default Task;