export const TASK_STATUS_TODO = 'To Do';
export const TASK_STATUS_IN_PROGRESS = 'In Progress';
export const TASK_STATUS_COMPLETED = 'Completed';